$(function () {
	const resizeHandler = () => {
		
		let navbarHeight = Math.round($('.navbar').height());
		
		$('.navbar-support').height(navbarHeight);
	};

	resizeHandler();
	window.addEventListener('resize', resizeHandler);
});

